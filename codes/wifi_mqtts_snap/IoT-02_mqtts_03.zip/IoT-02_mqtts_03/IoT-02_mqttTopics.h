#ifndef IOT_02_MQTT_TOPICS
#define IOT_02_MQTT_TOPICS

#define TOPIC_REQUEST_MAC "/macReq"
#define TOPIC_MAC "/mac"

#endif // IOT_02_MQTT_TOPICS
